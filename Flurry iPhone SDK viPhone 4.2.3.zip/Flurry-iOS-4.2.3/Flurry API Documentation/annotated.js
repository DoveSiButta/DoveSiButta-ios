var annotated =
[
    [ "Flurry", "interface_flurry.html", null ],
    [ "<FlurryAdDelegate>", "protocol_flurry_ad_delegate-p.html", "protocol_flurry_ad_delegate-p" ],
    [ "FlurryAds", "interface_flurry_ads.html", null ]
];