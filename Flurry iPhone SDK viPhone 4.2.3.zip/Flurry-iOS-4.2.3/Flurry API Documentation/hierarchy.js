var hierarchy =
[
    [ "NSObject", null, [
      [ "Flurry", "interface_flurry.html", null ],
      [ "FlurryAds", "interface_flurry_ads.html", null ]
    ] ],
    [ "<NSObject>", null, [
      [ "<FlurryAdDelegate>", "protocol_flurry_ad_delegate-p.html", null ]
    ] ]
];