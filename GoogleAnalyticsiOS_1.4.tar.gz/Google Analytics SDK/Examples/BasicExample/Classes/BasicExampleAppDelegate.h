//
//  BasicExampleAppDelegate.h
//  Google Analytics iOS SDK.
//
//  Copyright 2009 Google Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BasicExampleAppDelegate : NSObject <UIApplicationDelegate> {
  UIWindow *window_;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

